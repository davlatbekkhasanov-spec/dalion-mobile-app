module.exports = {
  name: 'auth'
};
