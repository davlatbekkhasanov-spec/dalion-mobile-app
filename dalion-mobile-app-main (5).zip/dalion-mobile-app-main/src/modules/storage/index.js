module.exports = {
  name: 'storage'
};
