module.exports = {
  name: 'users'
};
