module.exports = {
  name: 'catalog'
};
