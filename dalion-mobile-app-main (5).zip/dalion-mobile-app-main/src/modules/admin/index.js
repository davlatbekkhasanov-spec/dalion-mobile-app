module.exports = {
  name: 'admin'
};
