module.exports = {
  name: 'orders'
};
