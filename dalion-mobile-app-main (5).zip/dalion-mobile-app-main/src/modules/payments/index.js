module.exports = {
  name: 'payments'
};
