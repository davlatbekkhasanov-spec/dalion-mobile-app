module.exports = {
  name: 'checkout'
};
