module.exports = {
  name: 'courier'
};
