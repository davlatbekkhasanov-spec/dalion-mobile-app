module.exports = {
  name: 'integrations'
};
